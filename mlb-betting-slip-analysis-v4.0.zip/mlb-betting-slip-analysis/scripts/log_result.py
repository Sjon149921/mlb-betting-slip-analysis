#!/usr/bin/env python3
"""Append a published MLB leg and its result to the calibration log."""
from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path


LOG = Path(__file__).resolve().parents[1] / "logs" / "calibration.jsonl"


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--id", required=True)
    p.add_argument("--market", required=True)
    p.add_argument("--player", default="")
    p.add_argument("--team", default="")
    p.add_argument("--line", type=float, required=True)
    p.add_argument("--side", required=True)
    p.add_argument("--mean", type=float, required=True)
    p.add_argument("--p", type=float, required=True)
    p.add_argument("--actual", type=float, default=None)
    p.add_argument("--hit", type=int, default=None)
    p.add_argument("--note", default="")
    args = p.parse_args()
    LOG.parent.mkdir(parents=True, exist_ok=True)
    row = {
        "ts": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "id": args.id,
        "market": args.market,
        "player": args.player,
        "team": args.team,
        "line": args.line,
        "side": args.side,
        "mean": args.mean,
        "p_i": args.p,
        "actual": args.actual,
        "hit": args.hit,
        "note": args.note,
    }
    with LOG.open("a") as f:
        f.write(json.dumps(row) + "\n")
    print(f"appended {LOG}")


if __name__ == "__main__":
    main()
