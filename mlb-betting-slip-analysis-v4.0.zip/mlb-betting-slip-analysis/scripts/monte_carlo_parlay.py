#!/usr/bin/env python3
"""Monte Carlo joint-hit simulator for correlated parlay legs.

Reads JSON from a file path or stdin. Prints a compact report plus JSON.

Schema:
{
  "trials": 20000,
  "seed": 26,
  "legs": [
    {"id": "L1", "name": "KC ML", "p": 0.64, "cluster": "KC-BUF"}
  ],
  "pairs": [
    {"a": "L1", "b": "L2", "tag": "REINFORCE"}
  ]
}

Tags: IND, REINFORCE, COMPETE, NESTED, CONFLICT
NESTED means b is the broader/easier market or the component;
a is the harder/combo market and can hit only if b hits.
"""
from __future__ import annotations

import json
import math
import sys
from collections import defaultdict

try:
    import numpy as np
except ImportError:
    np = None


VALID_TAGS = {"IND", "REINFORCE", "COMPETE", "NESTED", "CONFLICT"}

RHO = {
    "REINFORCE": 0.50,
    "COMPETE": -0.35,
    "CONFLICT": -0.75,
    "IND": 0.0,
}


def _phi(z: float) -> float:
    return 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))


def _inv_phi(p: float) -> float:
    # Acklam approximation
    p = min(max(p, 1e-12), 1.0 - 1e-12)
    a = [
        -3.969683028665376e01,
        2.209460984245205e02,
        -2.759285104469687e02,
        1.383577509590705e02,
        -3.066479806614716e01,
        2.506628277459239e00,
    ]
    b = [
        -5.447609879822406e01,
        1.615858368580409e02,
        -1.556989798598866e02,
        6.680131188771972e01,
        -1.328068155288826e01,
    ]
    c = [
        -7.784894002430293e-03,
        -3.223964580411365e-01,
        -2.400758277161838e00,
        -2.549732539343734e00,
        4.374664141464968e00,
        2.938163982698783e00,
    ]
    d = [
        7.784695663188398e-03,
        3.224671290700398e-01,
        2.445134137142996e00,
        3.754408661907416e00,
    ]
    plow = 0.02425
    phigh = 1 - plow
    if p < plow:
        q = math.sqrt(-2 * math.log(p))
        return (((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]) / (
            (((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1
        )
    if p > phigh:
        q = math.sqrt(-2 * math.log(1 - p))
        return -(
            ((((c[0] * q + c[1]) * q + c[2]) * q + c[3]) * q + c[4]) * q + c[5]
        ) / ((((d[0] * q + d[1]) * q + d[2]) * q + d[3]) * q + 1)
    q = p - 0.5
    r = q * q
    return (
        (((((a[0] * r + a[1]) * r + a[2]) * r + a[3]) * r + a[4]) * r + a[5])
        * q
        / (((((b[0] * r + b[1]) * r + b[2]) * r + b[3]) * r + b[4]) * r + 1)
    )


def load_spec(path: str | None) -> dict:
    raw = sys.stdin.read() if not path else open(path, encoding="utf-8").read()
    spec = json.loads(raw)
    if "legs" not in spec or not spec["legs"]:
        raise SystemExit("spec must include a non-empty legs array")
    spec.setdefault("trials", 20000)
    spec.setdefault("seed", 26)
    spec.setdefault("pairs", [])
    for leg in spec["legs"]:
        if "id" not in leg or "p" not in leg:
            raise SystemExit("each leg needs id and p")
        leg["name"] = leg.get("name") or leg["id"]
        leg["cluster"] = str(leg.get("cluster") or "UNCLUSTERED")
        p = float(leg["p"])
        if not 0.0 < p < 1.0:
            raise SystemExit(f"leg {leg['id']} p must be in (0,1)")
        leg["p"] = p
    for pair in spec["pairs"]:
        tag = str(pair.get("tag", "IND")).upper()
        if tag not in VALID_TAGS:
            raise SystemExit(f"invalid tag {tag}")
        pair["tag"] = tag
    return spec


def pair_map(spec: dict) -> dict[tuple[str, str], str]:
    out = {}
    ids = {leg["id"] for leg in spec["legs"]}
    for pair in spec["pairs"]:
        a, b = pair["a"], pair["b"]
        if a not in ids or b not in ids:
            raise SystemExit(f"pair references unknown id: {a}, {b}")
        out[(a, b)] = pair["tag"]
        out[(b, a)] = pair["tag"]
    return out


def simulate(spec: dict) -> dict:
    legs = spec["legs"]
    n = len(legs)
    trials = int(spec["trials"])
    ids = [leg["id"] for leg in legs]
    p = {leg["id"]: leg["p"] for leg in legs}
    clusters = defaultdict(list)
    for leg in legs:
        clusters[leg["cluster"]].append(leg["id"])
    pmap = pair_map(spec)

    nested_parent = {}
    for pair in spec["pairs"]:
        if pair["tag"] == "NESTED":
            # a is harder/combo, b is component/easier
            nested_parent[pair["a"]] = pair["b"]

    if np is not None:
        rng = np.random.default_rng(int(spec["seed"]))
        cluster_z = {c: rng.standard_normal(trials) for c in clusters}
        idio = {i: rng.standard_normal(trials) for i in ids}
    else:
        import random

        random.seed(int(spec["seed"]))

        def nseq():
            return [random.gauss(0.0, 1.0) for _ in range(trials)]

        cluster_z = {c: nseq() for c in clusters}
        idio = {i: nseq() for i in ids}

    # Per-leg signed loading from cluster factor.
    loading = {i: 0.0 for i in ids}
    for (a, b), tag in pmap.items():
        if tag == "IND":
            continue
        if tag == "CONFLICT":
            loading[a] = max(loading[a], 0.70)
            loading[b] = min(loading[b], -0.70)
        elif tag == "REINFORCE":
            if loading[a] >= 0:
                loading[a] = max(loading[a], 0.50)
            if loading[b] >= 0:
                loading[b] = max(loading[b], 0.50)
        elif tag == "COMPETE":
            # keep modest shared factor; residual handled via cap
            if abs(loading[a]) < 0.25:
                loading[a] = 0.25
            if abs(loading[b]) < 0.25:
                loading[b] = 0.25

    zthr = {i: _inv_phi(p[i]) for i in ids}

    hits = {i: [False] * trials for i in ids}

    def val(arr, t):
        return float(arr[t])

    for t in range(trials):
        raw = {}
        for leg in legs:
            i = leg["id"]
            zc = val(cluster_z[leg["cluster"]], t)
            e = val(idio[i], t)
            lam = loading[i]
            # Gaussian copula against the cluster factor
            g = lam * zc + math.sqrt(max(1.0 - lam * lam, 1e-9)) * e
            raw[i] = g <= zthr[i]

        # Nested: combo cannot hit unless component hits
        for child, parent in nested_parent.items():
            if raw.get(child) and not raw.get(parent):
                raw[child] = False

        # Compete cap inside a cluster: if 3+ compete-tagged legs hit, drop extras
        for c, members in clusters.items():
            compete_ids = []
            for a in members:
                if any(pmap.get((a, b)) == "COMPETE" for b in members if b != a):
                    compete_ids.append(a)
            if len(compete_ids) >= 3:
                winners = [i for i in compete_ids if raw[i]]
                cap = len(compete_ids) - 1
                if len(winners) > cap:
                    # drop the lowest-p extras deterministically by trial index
                    winners_sorted = sorted(winners, key=lambda i: (p[i], i))
                    for drop in winners_sorted[: len(winners) - cap]:
                        raw[drop] = False

        # Conflict hard rule: both cannot hit
        seen = set()
        for pair in spec["pairs"]:
            if pair["tag"] != "CONFLICT":
                continue
            a, b = pair["a"], pair["b"]
            key = tuple(sorted((a, b)))
            if key in seen:
                continue
            seen.add(key)
            if raw[a] and raw[b]:
                # keep the higher-p leg
                if p[a] >= p[b]:
                    raw[b] = False
                else:
                    raw[a] = False

        for i in ids:
            hits[i][t] = raw[i]

    hit_counts = [0] * trials
    for t in range(trials):
        hit_counts[t] = sum(1 for i in ids if hits[i][t])

    all_hit = sum(1 for c in hit_counts if c == n) / trials
    n_minus_1 = sum(1 for c in hit_counts if c >= n - 1) / trials
    n_minus_2 = sum(1 for c in hit_counts if c >= n - 2) / trials
    exact = {}
    for k in range(0, n + 1):
        exact[k] = sum(1 for c in hit_counts if c == k) / trials
    mean_hits = sum(hit_counts) / trials
    individual = {i: sum(hits[i]) / trials for i in ids}
    j0 = 1.0
    for leg in legs:
        j0 *= leg["p"]

    return {
        "trials": trials,
        "n_legs": n,
        "J0": j0,
        "mc_all_hit": all_hit,
        "mc_at_least_n_minus_1": n_minus_1,
        "mc_at_least_n_minus_2": n_minus_2,
        "mean_hits": mean_hits,
        "exact_k_hits": exact,
        "realized_p": individual,
        "names": {leg["id"]: leg["name"] for leg in legs},
        "input_p": p,
    }


def format_report(result: dict) -> str:
    lines = []
    lines.append(f"trials={result['trials']}  legs={result['n_legs']}")
    lines.append(f"J0_independent={result['J0']:.6f}")
    lines.append(f"MC_all_hit={result['mc_all_hit']:.6f}")
    lines.append(f"MC_at_least_n-1={result['mc_at_least_n_minus_1']:.6f}")
    lines.append(f"MC_at_least_n-2={result['mc_at_least_n_minus_2']:.6f}")
    lines.append(f"mean_hits={result['mean_hits']:.3f}")
    lines.append("exact_k_hits=" + ", ".join(f"{k}:{v:.4f}" for k, v in sorted(result["exact_k_hits"].items())))
    lines.append("realized_p:")
    for i, name in result["names"].items():
        lines.append(f"  {i} {name}: input={result['input_p'][i]:.3f}  realized={result['realized_p'][i]:.3f}")
    return "\n".join(lines)


def main() -> None:
    path = sys.argv[1] if len(sys.argv) > 1 else None
    spec = load_spec(path)
    result = simulate(spec)
    print(format_report(result))
    print("---JSON---")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
