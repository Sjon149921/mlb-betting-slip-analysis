#!/usr/bin/env python3
"""Slot + pitcher quality → H / R / RBI means.

Happ over 1.5 vs Houck printed a 0.56 LEGAL because "bad starter = over."
A mid-order bat with a 24%+ K rate is still a coin against a replacement
arm. This script is the number. Feed its H/R/RBI into project_leg.py hrrbi.

Usage:
  python3 scripts/matchup_bat.py --slot 5 --woba 0.310 --batter_k 0.26 \\
      --sp_fip 5.40 --sp_k9 8.2 --team_runs 4.6 --line 1.5
"""
from __future__ import annotations

import argparse
import json
import math


SLOT_PA = {1: 4.45, 2: 4.35, 3: 4.25, 4: 4.15, 5: 4.05, 6: 3.95, 7: 3.85, 8: 3.75, 9: 3.65}
SLOT_RUN = {1: 1.12, 2: 1.08, 3: 1.10, 4: 1.08, 5: 0.96, 6: 0.90, 7: 0.86, 8: 0.82, 9: 0.78}
LG_WOBA = 0.320
LG_FIP = 4.20
LG_K9 = 8.6


def clamp(x: float, lo: float, hi: float) -> float:
    return min(hi, max(lo, x))


def means(slot: int, woba: float, batter_k: float, sp_fip: float, sp_k9: float, team_runs: float) -> dict:
    pa = SLOT_PA.get(slot, 4.0)
    # Combined K: half batter, half pitcher vs league.
    k = clamp(0.55 * batter_k + 0.45 * (sp_k9 / 38.0), 0.12, 0.42)
    bb = clamp(0.08 + 0.15 * (woba - LG_WOBA), 0.05, 0.14)
    in_play = max(0.40, 1.0 - k - bb)
    # BABIP proxy from wOBA leftover after K.
    babip = clamp(0.245 + 0.55 * (woba - 0.280), 0.220, 0.360)
    h = pa * in_play * babip
    # Soft FIP raises balls in play a bit, not a free over.
    fip_mult = clamp(0.82 + 0.18 * (sp_fip / LG_FIP), 0.80, 1.12)
    h *= fip_mult
    run_share = SLOT_RUN.get(slot, 0.95) * (team_runs / 9.0) * (0.85 + 0.5 * (woba / LG_WOBA - 1.0))
    r = max(0.15, pa * run_share * 0.22)
    rbi = max(0.15, h * (0.45 + 0.08 * max(0, 4 - slot)))
    # Happ rule: mid/low slot + high K is a wide SD, not a CORE over.
    high_k_mid = slot >= 5 and batter_k >= 0.24
    matchup = (woba / LG_WOBA) * SLOT_RUN.get(slot, 1.0) * (LG_FIP / max(sp_fip, 2.4))
    return {
        "pa": round(pa, 2),
        "k_rate": round(k, 3),
        "h": round(h, 3),
        "r": round(r, 3),
        "rbi": round(rbi, 3),
        "sum": round(h + r + rbi, 3),
        "matchup_index": round(matchup, 3),
        "high_k_mid": high_k_mid,
        "sd_bump": 1.15 if high_k_mid else 1.0,
    }


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--slot", type=int, required=True)
    p.add_argument("--woba", type=float, required=True)
    p.add_argument("--batter_k", type=float, required=True, help="batter K rate 0-1")
    p.add_argument("--sp_fip", type=float, required=True)
    p.add_argument("--sp_k9", type=float, default=LG_K9)
    p.add_argument("--team_runs", type=float, default=4.4)
    p.add_argument("--line", type=float, required=True)
    p.add_argument("--side", choices=["over", "under"], default="over")
    args = p.parse_args()
    m = means(args.slot, args.woba, args.batter_k, args.sp_fip, args.sp_k9, args.team_runs)
    total = m["sum"]
    gap = total - args.line if args.side == "over" else args.line - total
    flag = "LEGAL"
    if args.side == "over" and m["high_k_mid"] and gap < 1.0:
        flag = "EXTRA mid-order high-K vs any SP — not CORE"
    elif args.side == "over" and args.slot <= 4 and args.woba >= 0.340 and gap >= 0.40:
        flag = "LEGAL"
    elif args.side == "over" and (total < args.line + 0.60):
        flag = "EXTRA thin counting over — not CORE"
    elif args.side == "over" and m["matchup_index"] < 0.90 and args.slot >= 5:
        flag = "EXTRA weak slot/pitcher index — not CORE"
    out = {**m, "line": args.line, "side": args.side, "gap": round(gap, 3), "flag": flag}
    print(json.dumps(out, indent=2))
    print(
        f"\n# next: python3 scripts/project_leg.py hrrbi --h {m['h']} --r {m['r']} "
        f"--rbi {m['rbi']} --line {args.line} --side {args.side} --team_runs {args.team_runs}"
    )


if __name__ == "__main__":
    main()
