#!/usr/bin/env python3
"""Pull live MLB pitcher season + last-start stats from statsapi.mlb.com.

Usage:
  python3 scripts/fetch_pitcher.py --id 693645
  python3 scripts/fetch_pitcher.py --name "Cam Schlittler"
  python3 scripts/fetch_pitcher.py --id 693645 --line 7.5 --side under
"""
from __future__ import annotations

import argparse
import json
import subprocess
import sys
import urllib.parse
import urllib.request
from pathlib import Path

UA = "Mozilla/5.0 GrokSkill/3.4"
ROOT = Path(__file__).resolve().parent


def get(url: str) -> dict | None:
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode())
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc), "url": url}, indent=2))
        return None


def ip_to_float(ip: str | None) -> float:
    if not ip:
        return 0.0
    s = str(ip)
    if "." in s:
        whole, frac = s.split(".", 1)
        return float(whole) + (int(frac[0]) / 3.0 if frac else 0.0)
    return float(s)


def fip_approx(hr: float, bb: float, hbp: float, k: float, ip: float) -> float | None:
    if ip <= 0:
        return None
    return ((13 * hr + 3 * (bb + hbp) - 2 * k) / ip) + 3.20


def search_name(name: str) -> int | None:
    q = urllib.parse.quote(name)
    data = get(f"https://statsapi.mlb.com/api/v1/people/search?names={q}")
    if not data:
        return None
    people = data.get("people") or []
    if not people:
        # fallback suggest
        data = get(
            "https://statsapi.mlb.com/api/v1/sports/1/players?season=2026"
        )
        if not data:
            return None
        needle = name.lower()
        for p in data.get("people") or []:
            if needle in (p.get("fullName") or "").lower():
                return p.get("id")
        return None
    return people[0].get("id")


def last_starts(splits: list, n: int = 5) -> list[dict]:
    rows = []
    for s in reversed(splits or []):
        st = s.get("stat") or {}
        rows.append(
            {
                "date": (s.get("date") or ""),
                "ip": st.get("inningsPitched"),
                "pitches": st.get("numberOfPitches"),
                "k": st.get("strikeOuts"),
                "bb": st.get("baseOnBalls"),
                "er": st.get("earnedRuns"),
                "h": st.get("hits"),
                "gs": st.get("gamesStarted"),
            }
        )
        if len(rows) >= n:
            break
    return rows


def build(pid: int) -> dict:
    person = get(f"https://statsapi.mlb.com/api/v1/people/{pid}")
    name = None
    throws = None
    if person:
        p0 = (person.get("people") or [{}])[0]
        name = p0.get("fullName")
        throws = (p0.get("pitchHand") or {}).get("code")
    season = get(
        f"https://statsapi.mlb.com/api/v1/people/{pid}/stats"
        f"?stats=season&group=pitching&season=2026&sportId=1"
    )
    log = get(
        f"https://statsapi.mlb.com/api/v1/people/{pid}/stats"
        f"?stats=gameLog&group=pitching&season=2026&sportId=1"
    )
    st = {}
    if season:
        splits = ((season.get("stats") or [{}])[0].get("splits") or [{}])
        st = (splits[0].get("stat") if splits else {}) or {}
    ip = ip_to_float(st.get("inningsPitched"))
    gs = float(st.get("gamesStarted") or 0) or 1.0
    k = float(st.get("strikeOuts") or 0)
    bb = float(st.get("baseOnBalls") or 0)
    h = float(st.get("hits") or 0)
    hr = float(st.get("homeRuns") or 0)
    hbp = float(st.get("hitByPitch") or 0)
    k9 = (k * 9 / ip) if ip else None
    bb9 = (bb * 9 / ip) if ip else None
    ip_start = ip / gs if gs else None
    log_splits = ((log.get("stats") or [{}])[0].get("splits") if log else []) or []
    recent = last_starts(log_splits, 5)
    last = recent[0] if recent else {}
    last_ip = ip_to_float(last.get("ip"))
    last_pitches = last.get("pitches")
    cap_hint = None
    if last_pitches is not None and last_pitches <= 75:
        cap_hint = "LAST_START_LEASH"
    if last_ip and last_ip < 4.5 and last.get("gs"):
        cap_hint = cap_hint or "LAST_START_SHORT"
    return {
        "ok": True,
        "source": "statsapi.mlb.com",
        "id": pid,
        "name": name,
        "throws": throws,
        "season": {
            "era": st.get("era"),
            "whip": st.get("whip"),
            "ip": st.get("inningsPitched"),
            "gs": st.get("gamesStarted"),
            "k": st.get("strikeOuts"),
            "bb": st.get("baseOnBalls"),
            "k9": round(k9, 2) if k9 else None,
            "bb9": round(bb9, 2) if bb9 else None,
            "ip_per_start": round(ip_start, 2) if ip_start else None,
            "fip_approx": round(fip_approx(hr, bb, hbp, k, ip), 2) if ip else None,
        },
        "last_start": last,
        "last_5": recent,
        "cap_hint": cap_hint,
        "suggest": {
            "k9": round(k9, 2) if k9 else None,
            "ip": round(ip_start, 2) if ip_start else None,
            "pitches": last_pitches,
        },
    }


def run_projectors(row: dict, line: float, side: str) -> dict:
    sug = row.get("suggest") or {}
    k9 = sug.get("k9")
    ip = sug.get("ip")
    if k9 is None or ip is None:
        return {"ok": False, "error": "missing k9/ip"}
    pitches = sug.get("pitches")
    cmd_k = [
        sys.executable,
        str(ROOT / "expected_k.py"),
        "--k9",
        str(k9),
        "--ip",
        str(ip),
        "--line",
        str(line),
    ]
    if pitches is not None and pitches <= 75:
        cmd_k += ["--pitches", str(pitches)]
    ek = subprocess.run(cmd_k, capture_output=True, text=True)
    cmd_p = [
        sys.executable,
        str(ROOT / "project_leg.py"),
        "k",
        "--k9",
        str(k9),
        "--ip",
        str(ip),
        "--line",
        str(line),
        "--side",
        side,
    ]
    if pitches is not None and pitches <= 75:
        cmd_p += ["--pitches", str(pitches)]
    pl = subprocess.run(cmd_p, capture_output=True, text=True)
    proj = None
    try:
        proj = json.loads(pl.stdout)
    except Exception:
        proj = {"raw": pl.stdout, "err": pl.stderr}
    return {
        "expected_k_stdout": ek.stdout.strip(),
        "project_leg": proj,
        "cmd": " ".join(cmd_p),
    }


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--id", type=int)
    ap.add_argument("--name")
    ap.add_argument("--line", type=float)
    ap.add_argument("--side", choices=["over", "under"], default="over")
    args = ap.parse_args()
    pid = args.id
    if not pid and args.name:
        pid = search_name(args.name)
    if not pid:
        print(json.dumps({"ok": False, "error": "need --id or --name"}, indent=2))
        sys.exit(1)
    row = build(pid)
    if args.line is not None:
        row["piped"] = run_projectors(row, args.line, args.side)
    print(json.dumps(row, indent=2))


if __name__ == "__main__":
    main()
