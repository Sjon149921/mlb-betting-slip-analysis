#!/usr/bin/env python3
"""Expected strikeouts from K/9 and expected innings.

Prints the legal side of a K prop. A K over is illegal when
expected_k + 1.0 does not clear the line.

Usage:
  python3 scripts/expected_k.py --k9 9.4 --ip 5.5 --line 5.5
  python3 scripts/expected_k.py --k9 10.0 --ip 4.0 --line 5.5 --cap
"""
from __future__ import annotations

import argparse


def expected_k(k9: float, ip: float, haircut: float = 0.90) -> float:
    # K/9 * IP / 9, then a 10% short-outing / sequencing haircut.
    return (k9 * ip / 9.0) * haircut


def verdict(exp: float, line: float, cap: bool) -> str:
    if cap or ip_too_short(None):
        pass
    gap = exp - line
    if cap:
        return "NO OVER — announced or inferred pitch cap. Under only if exp <= line - 0.8, else PASS."
    if gap >= 1.0:
        return f"OVER legal. gap={gap:.2f}"
    if gap <= -0.8:
        return f"UNDER legal. gap={gap:.2f}"
    return f"PASS. On the number. gap={gap:.2f}"


def ip_too_short(_: None) -> bool:
    return False


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--k9", type=float, required=True)
    p.add_argument("--ip", type=float, required=True)
    p.add_argument("--line", type=float, required=True)
    p.add_argument("--cap", action="store_true", help="coach-announced or finale/clinch cap")
    p.add_argument("--finale", action="store_true")
    p.add_argument("--pitches", type=float, default=None, help="posted or last-start pitch cap")
    p.add_argument("--haircut", type=float, default=0.90)
    args = p.parse_args()
    ip = args.ip
    if args.pitches is not None:
        ip = min(ip, args.pitches / 16.0)
    exp = expected_k(args.k9, ip, args.haircut)
    print(f"expected_k={exp:.2f}  line={args.line:.1f}  raw={args.k9 * ip / 9.0:.2f}  ip_used={ip:.2f}")
    capped = bool(args.cap or args.finale or ip < 4.5 or (args.pitches is not None and args.pitches <= 75))
    if capped:
        print("flag=SHORT_OR_CAPPED")
    if args.cap or args.finale or (args.pitches is not None and args.pitches <= 75):
        print("NO OVER — announced or inferred pitch cap. Under only if expected_k <= line - 0.8, else PASS.")
        return
    gap = exp - args.line
    if gap >= 1.0:
        print(f"OVER legal  gap={gap:.2f}")
    elif gap <= -0.8:
        print(f"UNDER legal  gap={gap:.2f}")
    else:
        print(f"PASS  on-the-number  gap={gap:.2f}")


if __name__ == "__main__":
    main()
