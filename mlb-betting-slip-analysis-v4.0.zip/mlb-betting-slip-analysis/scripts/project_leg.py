#!/usr/bin/env python3
"""MLB single-leg projection.

CORE is illegal until mean, sd, p_i, and two-source agreement print.

Usage:
  python3 scripts/project_leg.py k --k9 10.4 --ip 5.8 --k_rate 0.27 --line 5.5 --side over
  python3 scripts/project_leg.py k --k9 10.0 --ip 4.0 --line 5.5 --side over --cap
  python3 scripts/project_leg.py hrrbi --h 1.05 --r 0.70 --rbi 0.85 --line 2.5 --side under --team_runs 5.8
  python3 scripts/project_leg.py runs --mean 3.4 --sd 2.4 --line 4.5 --side under
  python3 scripts/project_leg.py winner --runs 4.6 --opp 3.2 --motivation fighting --opp_motivation eliminated
"""
from __future__ import annotations

import argparse
import json
import math


def phi(z: float) -> float:
    return 0.5 * (1.0 + math.erf(z / math.sqrt(2.0)))


def poisson_pmf(k: int, lam: float) -> float:
    if lam <= 0:
        return 1.0 if k == 0 else 0.0
    return math.exp(k * math.log(lam) - lam - math.lgamma(k + 1))


def poisson_over_p(lam: float, line: float) -> float:
    cap = int(math.floor(line))
    return 1.0 - sum(poisson_pmf(k, lam) for k in range(cap + 1))


def clamp_p(p: float, lo: float = 0.05, hi: float = 0.95) -> float:
    # Keep raw model probability available for calibration. Ticket construction
    # can apply its own conservative haircut/cap later.
    return min(hi, max(lo, p))


def emit(d: dict) -> None:
    print(json.dumps(d, indent=2))


def main() -> None:
    ap = argparse.ArgumentParser()
    sub = ap.add_subparsers(dest="cmd", required=True)

    k = sub.add_parser("k")
    k.add_argument("--k9", type=float, required=True)
    k.add_argument("--ip", type=float, required=True)
    k.add_argument("--k_rate", type=float, default=None, help="BF K rate vs this lineup; overrides k9 if set")
    k.add_argument("--bf", type=float, default=None)
    k.add_argument("--line", type=float, required=True)
    k.add_argument("--side", choices=["over", "under"], default="over")
    k.add_argument("--cap", action="store_true")
    k.add_argument("--finale", action="store_true", help="last week / clinch / finale start: treat as capped unless 5+ IP confirmed")
    k.add_argument("--pitches", type=float, default=None, help="posted pitch cap or last-start count")
    k.add_argument("--other", type=float, default=None)

    h = sub.add_parser("hrrbi")
    h.add_argument("--h", type=float, required=True)
    h.add_argument("--r", type=float, required=True)
    h.add_argument("--rbi", type=float, required=True)
    h.add_argument("--line", type=float, required=True)
    h.add_argument("--side", choices=["over", "under"], default="over")
    h.add_argument("--team_runs", type=float, default=4.4)
    h.add_argument("--elite", action="store_true")
    h.add_argument("--ace", action="store_true", help="opposing SP FIP or ERA at or under 3.00")
    h.add_argument("--other", type=float, default=None)

    r = sub.add_parser("runs")
    r.add_argument("--mean", type=float, required=True)
    r.add_argument("--sd", type=float, default=2.4)
    r.add_argument("--line", type=float, required=True)
    r.add_argument("--side", choices=["over", "under"], default="over")
    r.add_argument("--other", type=float, default=None)

    w = sub.add_parser("winner")
    w.add_argument("--runs", type=float, required=True)
    w.add_argument("--opp", type=float, required=True)
    w.add_argument("--sd", type=float, default=2.6)
    w.add_argument("--motivation", choices=["fighting", "locked", "eliminated"], default="fighting")
    w.add_argument("--opp_motivation", choices=["fighting", "locked", "eliminated"], default="fighting")
    w.add_argument("--other", type=float, default=None, help="market implied win p")

    args = ap.parse_args()

    if args.cmd == "k":
        ip = args.ip
        if args.pitches is not None:
            ip = min(ip, args.pitches / 16.0)
        bf = args.bf if args.bf is not None else min(ip * 4.3, (args.pitches / 4.0) if args.pitches else ip * 4.3)
        raw = args.k9 * ip / 9.0
        if args.k_rate is not None:
            raw = bf * args.k_rate
        mean = raw * 0.90
        flag_cap = bool(args.cap or args.finale or ip < 4.5 or (args.pitches is not None and args.pitches <= 75))
        p_over = poisson_over_p(mean, args.line)
        p = p_over if args.side == "over" else 1.0 - p_over
        p_raw = p
        p_c = clamp_p(p)
        gap = mean - args.line if args.side == "over" else args.line - mean
        other = args.other if args.other is not None else mean
        agree = (mean - args.line) * (other - args.line) >= 0
        if flag_cap and args.side == "over":
            flag = "ILLEGAL capped/short start K over"
        elif args.side == "over" and gap < 1.0:
            flag = "ILLEGAL K over gap under 1.0"
        elif args.side == "under" and gap < 0.8:
            flag = "ILLEGAL K under gap under 0.8"
        elif not agree:
            flag = "ILLEGAL two-source split"
        elif p_c < 0.56:
            flag = "ILLEGAL p_i below 0.56"
        else:
            flag = "LEGAL"
        emit({
            "market": "k",
            "mean": round(mean, 2),
            "raw": round(raw, 2),
            "ip": round(ip, 2),
            "ip_listed": args.ip,
            "pitches": args.pitches,
            "bf": round(bf, 1),
            "line": args.line,
            "side": args.side,
            "gap": round(gap, 2),
            "p_raw": round(p_raw, 4),
            "p_i": round(p_c, 4),
            "capped": flag_cap,
            "two_source_agree": agree,
            "flag": flag,
        })
        return

    if args.cmd == "hrrbi":
        mean = args.h + args.r + args.rbi
        # positive dependence; do not treat as three independent Poissons
        var = args.h + args.r + args.rbi + 0.35 * (args.h + args.r + args.rbi)
        sd = math.sqrt(max(var, 0.8))
        p_over = 1.0 - phi((args.line - mean) / sd)
        p = p_over if args.side == "over" else 1.0 - p_over
        p_c = clamp_p(p)
        if args.elite and args.side == "under" and args.team_runs >= 5.0:
            flag = "ILLEGAL elite-bat under in a high-run script"
        elif args.side == "under" and args.team_runs >= 6.0:
            flag = "ILLEGAL counting under in a blowout-script offense"
        elif args.ace and args.side == "over" and (p_c < 0.60 or mean < args.line + 0.8):
            flag = "EXTRA vs ace — not CORE"
        elif args.side == "over" and (p_c < 0.60 or mean < args.line + 0.50):
            flag = "EXTRA thin counting over — not CORE"
        elif p_c < 0.52:
            flag = "ILLEGAL p_i below 0.52"
        elif p_c < 0.56:
            flag = "EXTRA thin gap — not CORE"
        else:
            flag = "LEGAL"
        emit({
            "market": "hrrbi",
            "mean": round(mean, 2),
            "sd": round(sd, 2),
            "line": args.line,
            "side": args.side,
            "team_runs": args.team_runs,
            "p_i": round(p_c, 4),
            "flag": flag,
        })
        return

    if args.cmd == "runs":
        p_over = 1.0 - phi((args.line - args.mean) / args.sd)
        p = p_over if args.side == "over" else 1.0 - p_over
        p_c = clamp_p(p)
        other = args.other if args.other is not None else args.mean
        agree = (args.mean - args.line) * (other - args.line) >= 0
        gap = args.mean - args.line if args.side == "over" else args.line - args.mean
        flag = "LEGAL" if p_c >= 0.56 and agree and gap >= 0.8 else "ILLEGAL"
        emit({
            "market": "runs",
            "mean": round(args.mean, 2),
            "sd": args.sd,
            "line": args.line,
            "p_i": round(p_c, 4),
            "two_source_agree": agree,
            "flag": flag,
        })
        return

    # winner
    diff = args.runs - args.opp
    sd_diff = math.sqrt(2) * args.sd
    p_raw = phi(diff / sd_diff) if sd_diff else (1.0 if diff > 0 else 0.0)
    if args.motivation == "eliminated" and args.opp_motivation != "eliminated":
        p_raw *= 0.78
        flag_m = "eliminated-road haircut"
    elif args.motivation == "locked" and args.opp_motivation == "fighting":
        p_raw *= 0.88
        flag_m = "locked vs fighting haircut"
    else:
        flag_m = "ok"
    if abs(diff) < 0.8:
        p_raw = min(p_raw, 0.58)
    p_c = clamp_p(p_raw, hi=0.64)
    market_p = args.other if args.other is not None else p_c
    agree = abs(p_c - market_p) <= 0.10 and (p_c - 0.5) * (market_p - 0.5) >= 0
    if args.motivation == "eliminated":
        flag = "ILLEGAL eliminated-team winner"
    elif p_c < 0.56 or not agree:
        flag = "ILLEGAL winner coin or two-source split"
    else:
        flag = "LEGAL"
    emit({
        "market": "winner",
        "runs": args.runs,
        "opp": args.opp,
        "p_raw": round(p_raw, 4),
        "p_i": round(p_c, 4),
        "motivation": args.motivation,
        "opp_motivation": args.opp_motivation,
        "motivation_note": flag_m,
        "two_source_agree": agree,
        "flag": flag,
    })


if __name__ == "__main__":
    main()
