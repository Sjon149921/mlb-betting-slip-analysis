#!/usr/bin/env python3
"""Live MLB slate: probable pitchers, listed lineups, last-start pitch count.

Pitch cap is an input. If last start or notes show a cap, pass that number
into expected_k.py --pitches. Do not guess 100.

Usage:
  python3 scripts/fetch_slate.py --team CHC
  python3 scripts/fetch_slate.py --date 2026-09-27
"""
from __future__ import annotations

import argparse
import json
import sys
import urllib.parse
import urllib.request
from datetime import date


UA = "Mozilla/5.0 GrokSkill/3.3"


def get(url: str) -> dict | None:
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=12) as resp:
            return json.loads(resp.read().decode())
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc), "url": url}, indent=2))
        return None


def pitcher_blob(team_side: dict) -> dict:
    pp = (team_side or {}).get("probablePitcher") or {}
    return {
        "id": pp.get("id"),
        "name": pp.get("fullName"),
    }


def enrich_pitcher(pid: int | None) -> dict | None:
    if not pid:
        return None
    # Local import-free call via people + season stats.
    season = get(
        f"https://statsapi.mlb.com/api/v1/people/{pid}/stats"
        f"?stats=season&group=pitching&season=2026&sportId=1"
    )
    log = get(
        f"https://statsapi.mlb.com/api/v1/people/{pid}/stats"
        f"?stats=gameLog&group=pitching&season=2026&sportId=1"
    )
    if not season:
        return None

    def ip_to_float(ip: str | None) -> float:
        if not ip:
            return 0.0
        s = str(ip)
        if "." in s:
            whole, frac = s.split(".", 1)
            return float(whole) + (int(frac[0]) / 3.0 if frac else 0.0)
        return float(s)

    splits = ((season.get("stats") or [{}])[0].get("splits") or [{}])
    st = (splits[0].get("stat") if splits else {}) or {}
    ip = ip_to_float(st.get("inningsPitched"))
    gs = float(st.get("gamesStarted") or 0) or 1.0
    k = float(st.get("strikeOuts") or 0)
    log_splits = ((log.get("stats") or [{}])[0].get("splits") if log else []) or []
    last = {}
    if log_splits:
        last_st = (log_splits[-1].get("stat") or {})
        last = {
            "ip": last_st.get("inningsPitched"),
            "pitches": last_st.get("numberOfPitches"),
            "k": last_st.get("strikeOuts"),
            "gs": last_st.get("gamesStarted"),
        }
    return {
        "era": st.get("era"),
        "whip": st.get("whip"),
        "ip": st.get("inningsPitched"),
        "gs": st.get("gamesStarted"),
        "k": st.get("strikeOuts"),
        "k9": round(k * 9 / ip, 2) if ip else None,
        "ip_per_start": round(ip / gs, 2) if gs else None,
        "last_start": last,
    }


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--team", default=None, help="team abbreviation e.g. CHC")
    p.add_argument("--date", default=None, help="YYYY-MM-DD, default today")
    p.add_argument("--enrich", action="store_true", help="attach season K/9, IP/start, last-start pitches")
    args = p.parse_args()
    day = args.date or date.today().isoformat()
    url = (
        "https://statsapi.mlb.com/api/v1/schedule?sportId=1&date="
        + urllib.parse.quote(day)
        + "&hydrate=probablePitcher,lineups,venue,weather"
    )
    data = get(url)
    if not data:
        sys.exit(1)
    games = []
    for d in data.get("dates") or []:
        for g in d.get("games") or []:
            teams = g.get("teams") or {}
            away = (teams.get("away") or {}).get("team") or {}
            home = (teams.get("home") or {}).get("team") or {}
            away_pp = (teams.get("away") or {}).get("probablePitcher") or {}
            home_pp = (teams.get("home") or {}).get("probablePitcher") or {}
            row = {
                "gamePk": g.get("gamePk"),
                "status": (g.get("status") or {}).get("detailedState"),
                "away": away.get("abbreviation") or away.get("name"),
                "home": home.get("abbreviation") or home.get("name"),
                "away_sp": away_pp.get("fullName"),
                "home_sp": home_pp.get("fullName"),
                "away_sp_id": away_pp.get("id"),
                "home_sp_id": home_pp.get("id"),
                "venue": (g.get("venue") or {}).get("name"),
                "weather": g.get("weather"),
                "lineups_posted": bool(g.get("lineups")),
            }
            if args.enrich:
                row["away_sp_stats"] = enrich_pitcher(away_pp.get("id"))
                row["home_sp_stats"] = enrich_pitcher(home_pp.get("id"))
            if args.team and args.team.upper() not in {str(row["away"]).upper(), str(row["home"]).upper(), ""}:
                an = (away.get("name") or "").upper()
                hn = (home.get("name") or "").upper()
                if args.team.upper() not in an and args.team.upper() not in hn and args.team.upper() not in {
                    str(away.get("abbreviation") or "").upper(),
                    str(home.get("abbreviation") or "").upper(),
                }:
                    continue
            games.append(row)
    out = {"ok": True, "date": day, "games": games}
    print(json.dumps(out, indent=2))
    print("\n# If lineups_posted is false, batter slots are UNCONFIRMED.")
    print("# Pipe a pitcher into projectors:")
    print('#   python3 scripts/fetch_pitcher.py --name "Cam Schlittler" --line 7.5 --side under')


if __name__ == "__main__":
    main()
