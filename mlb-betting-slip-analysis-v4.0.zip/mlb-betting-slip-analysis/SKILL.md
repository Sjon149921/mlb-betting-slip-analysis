---
name: mlb-betting-slip-analysis
description: Analyze and build MLB moneyline, run-line, total, F5, and prop betting slips using statistically grounded guidelines. Use when evaluating baseball moneylines, pitcher props, hit-run-RBI props, constructing parlays or slips, running slip intake, checking correlation math, running Monte Carlo joint-hit sims, or executing /run audit. Also use for starting pitcher edges, bullpen workload, park or umpire context, or prop-specific filters for strikeouts and combined stats.
metadata:
  type: workflow
  version: "4.0"
---

# MLB Betting Slip Analysis

Apply these evidence-based rules when evaluating or constructing MLB slips. Prioritize clear statistical mismatches over favorites, short streaks, or single-player heat. Continuously incorporate lessons from recent failed and winning legs.

When building or auditing a live slip, also read `references/projection-framework.md`, `references/data-quality-and-api.md`, and `references/output-and-intake.md`, `references/projection-engine.md`, `references/markets-and-filters.md`, `references/correlation-math.md`, `references/victory-gates.md`, `references/finale-script-gates.md`, and `references/calibration.md`.


## v4.0 Projection and Data-Quality Rules

The prediction engine is now explicitly ordered: **opportunity → matchup-adjusted efficiency → game-script distribution → mean/median/SD → probability → second-source validation → robustness → correlation → kill shots → calibration**. Read `references/projection-framework.md`.

Do not use season averages as a projection by themselves. Every CORE leg needs a quantified opportunity estimate and a matchup-adjusted efficiency estimate. Model at least three plausible script states when the market is script-sensitive. Report mean, median, SD, p_model, and the line.

Separate prediction from bet quality: p_model answers how likely the outcome is; edge compares that probability with a usable market probability; robustness measures sensitivity to reasonable input changes. Never manufacture a p_i to make a ticket work.

Treat API data as an accuracy enabler, not an accuracy guarantee. Follow `references/data-quality-and-api.md`. Never hard-code API keys. If required live fields cannot be verified, downgrade the leg rather than inventing them. Preserve point-in-time integrity in all backtests.

Replace universal probability ceilings with calibration-aware risk controls. The displayed p_i may be conservatively capped for ticket construction, but the raw model probability must be retained for calibration.

After each result, classify the miss as model error, data error, workload/opportunity error, script error, correlation/construction error, or normal variance. Only change thresholds from adequate sample sizes by market bucket.

## Workflow and Commands

If games, ticket type, or leg count are missing, run the intake in `references/output-and-intake.md` and wait. Do not invent a slate.

- Skill start / "build slip" → intake, then projection engine, then gates, then the fixed output template.
- `/run audit` → refresh SP, lineup, weather, pitch cap; re-run `scripts/project_leg.py` and `scripts/expected_k.py`; re-run Monte Carlo. Verdict HOLD, CUT-AND-REPLACE, or KILL TICKET.

Every CORE row must come from `scripts/project_leg.py` (mean, p_i, LEGAL flag). K overs also need `scripts/expected_k.py`. Do not invent p_i. After the game, append results with `scripts/log_result.py`.

Live inputs (v3.4):
- `python3 scripts/fetch_slate.py --date YYYY-MM-DD --enrich` pulls probable SPs plus season ERA/WHIP/K/9/IP-per-start and last-start pitch count from statsapi.mlb.com. Do not invent those fields.
- `python3 scripts/fetch_pitcher.py --name "Cam Schlittler" --line 7.5 --side under` pipes live K/9 and IP/start into `expected_k.py` and `project_leg.py`. `--pitches` is last-start count; a 70-pitch leash last time is a hint, not automatic Game 1 cap. Confirm workload before treating WC/playoff starts as capped.
- K props take `--pitches` (posted cap or last-start count). `--finale` is only the fallback when the cap is unknown.
- Batter overs run `scripts/matchup_bat.py` first (slot + wOBA + batter K% + SP FIP/K9), then pipe H/R/RBI into `project_leg.py hrrbi`. Season slash lines are still not on the Stats API hydrate; slots stay UNCONFIRMED until lineups post.

Cross-sport: winner cap is 2 for the whole ticket. 8+ legs under 5x is a rebuild.

## Core Principles

A moneyline win is driven by which team is more likely to outscore the other over nine innings. Focus on pitching advantage, lineup matchup vs handedness, bullpen health, and run environment. One-game samples are noisy — require large, multi-factor edges.

PrizePicks / Predict "Winner" is a full-game moneyline contract with no push and no F5 escape hatch. A 5–4 walk-off is a full miss. Close ML stacks fail the same way NFL 3-point winner stacks fail: four ~55% coins on an all-must-hit card is not a core. Cap mixed Power Play CORE at 2 full-game ML / winner legs. Prefer F5 ML when the edge is the starter and the doubt is the pen. Do not convert "they keep it close" into a winner lean — use the run line when the platform offers it.

Explicitly look for structural similarities to recent winning sides (elite or clearly superior SP vs weak or eliminated opponent in a favorable run environment) and actively avoid patterns that produced recent losses (favorite with SP edge that still lost due to short outing, clinched-team rest, or late-inning collapse).

Independently determine what is statistically most likely. Sportsbook price is not proof of probability. Never force a pick when evidence is weak. Do not take an elite-bat counting-stat under against a punching-bag staff (Alvarez under 2.5 H+R+RBI in a 9–0 Astros win). That is a script conflict, not a fade. Do not use chalk MLs as padding for thin K overs or batter unders. If the user already has the other side of a game live on another platform, refuse the opposite winner.

## Data Collection

Confirm before analysis:

- Both starting pitchers, handedness, pitch mix, and expected workload (full start vs opener vs pitch cap)
- Confirmed or projected lineups and batting-order slots
- Platoon construction vs the opposing starter
- Last 3–5 starts for each SP (ERA, FIP/xFIP, WHIP, K/9, BB/9, CSW%, velocity trend)
- Opponent last 7–10 games OPS and K% vs that handedness
- Bullpen ERA/WHIP and high-leverage usage last 48–72 hours
- Park run, HR, and K factors
- Weather, wind direction vs the park's HR alley, temperature
- Umpire K/BB and zone tendencies when available
- Late-season clinch, seeding, or elimination status
- IL returns, catcher, and defensive alignment notes
- Current ML, run line, full-game total, F5 markets, and prop lines

If a starter, lineup, or weather reading is unconfirmed, flag the uncertainty. Do not invent data.

## 1. Starting Pitcher Advantage (Primary Factor)

- Require a clear gap in ERA, FIP/xFIP, WHIP, and strikeout rate (K/9 or K%).
- Weight last 3–5 starts over full-season numbers when a trend is real (velo drop, rising walk rate, or a genuine stuff spike).
- Avoid high-walk starters and poor platoon splits vs the opposing lineup's handedness.
- Even large SP gaps fail in single games. Require the gap to be large AND the opposing lineup’s last 7–10 games OPS not to be surging.
- **Workload filter**: Confirm a normal outing (target 5+ IP). Short-leash, opener, bullpen game, farewell start, or playoff-prep cap (example pattern: Cam Schlittler limited to 3 IP on 9/24/26; Jared Jones scheduled 4 IP on 9/27/26 and missed 5.5 Ks with 5; Parker Messick 3 IP the day after a division clinch and missed 3.5 Ks with 2) destroys K props and shrinks team edge.
- Prefer SPs whose recent outings match winning legs — deep innings, high K rate, low WHIP against similar opponent quality.
- Velocity down ~1.5 mph over a 3-start window is a fade signal until recovered.
- Do not treat a "soft ERA" as a batter-over green light if the pitcher is not expected to face the order a third time.

## 2. Full Lineup vs Pitcher Matchup

- Compare the starter against the entire order, not star names.
- Prefer higher team BA/OBP/power vs that pitcher profile and handedness.
- High-K lineups are vulnerable to elite miss-bat stuff.
- Platoon and slot are mandatory. Leadoff/2-hole/3-hole vs a high-WHIP opposite-hand starter outranks a star hitting seventh or same-handed.
- First-time-facing-pitcher samples are too small to be a primary reason to bet.

## 3. Bullpen Quality and Workload

- Starters now average roughly five innings. The pen often decides full-game ML, run line, and totals.
- Check last 2–3 days of high-leverage usage. A burned pen turns an SP edge into a late-game coin flip.
- Flag recent late-inning collapses by the favorite (example pattern: Braves 6-7 vs Reds on 9/24/26 despite an SP edge).
- If conviction is in the starter and doubt is in the pen, prefer F5 ML or F5 run line over the full-game ML.
- Opener or scheduled bullpen game invalidates F5-as-starter-isolation logic. Treat those games as pen games from pitch one.

## 4. Offensive Consistency and Run Environment

- Build totals from starters + pens + park + weather + umpire, not from season team runs alone.
- High-run parks (Coors especially; also GABP and similar) support low-threshold batter props and overs. Pitcher-friendly parks (Petco, T-Mobile, Oracle) support unders and K overs.
- Coors suppresses some pitch movement — do not auto-take pitcher K overs there.
- Late-season games with playoff implications often tighten. Favor clear mismatches. Reduce slight-favorite MLs in projected pitchers' duels.
- Wind blowing out to a HR alley is a real total/HR adjustment; wind in is a real under adjustment. Temperature and humidity matter more in warm hitter parks.

## 5. Situational and Contextual Edges

- Home field is secondary to pitching and lineup quality.
- Late-season motivation is often decisive. Clinched or locked-seed teams under-perform relative to paper SP edges. Prefer sides still playing for seeding, a division, or with elimination pressure on the opponent.
- Day game after night game, long travel, and getaway-day lineups can quietly cut offensive quality. Confirm the actual lineup.
- Weather delays raise starter pitch-count and short-outing risk.

## 6. Market Map — Use the Market That Matches the Edge

| If the edge is... | Prefer |
| --- | --- |
| Starter quality, doubt the pen | F5 ML or F5 total |
| Starter + pen + motivation | Full-game ML |
| Large favorite in a pen game | Fade or avoid run line -1.5 |
| Park + weather + two soft SPs | Full-game total over |
| Two strong SPs, cold/wind-in, tight zone | Total under or F5 under |
| Full-workload miss-bat arm vs high-K lineup | Pitcher K over |
| Confirmed pitch cap or opener | No K over; consider K under only if math clears |

Do not default every edge onto a full-game moneyline.

## 7. Prop-Specific Rules

### Strikeout Overs

- Compute `expected_k = (K/9 × expected_IP / 9) × 0.90` with `scripts/expected_k.py` before the side is legal.
- Last 3–5 starts average well above the line AND opponent K% is above league average.
- Moderate lines (4.5–5.5) on good-but-not-elite arms are high-risk. Prefer elite miss-batters.
- Confirm 5+ IP expected. Short final starts invalidate the over. A 4-IP leash vs a 5.5 line is not close — it is above the pitcher's ceiling that day (Jones 5 Ks vs 5.5).
- Haircut K overs at Coors and in extreme wind.
- Umpire with a wide zone can help K overs; a tight zone hurts them.
- Season-finale / post-clinch starts default to no K over. See `references/finale-script-gates.md`.

### Strikeout Unders

- Take only when K/9 × expected innings sits clearly below the line (example: 5.55 K/9 over 5 IP projects ~3.1 K vs a 3.5 line).
- Do not under a 12 K/9 arm on 6.5 just because it is late September unless a pitch cap is confirmed.

### 0.5 Hits + Runs + RBIs and Batter Overs

- Only take when (a) the batter’s team is projected for 4.5+ runs, or (b) the opposing starter has high WHIP / soft recent form AND will work a normal start.
- Hits-allowed and H/9 of the opposing starter are mandatory. Season BA alone is not enough.
- Avoid stacking multiple 0.5 combined props on the same slip, especially in low-scoring projected games.
- Elite-bat H / R / RBI / H+R+RBI unders are off CORE unless a true ace or a rest day is the reason. Alvarez under 2.5 in a 9–0 Houston win is a script conflict. See `references/finale-script-gates.md`.
- Never under 0.5 hits vs high-WHIP / high-H/9 profiles for anyone who puts the ball in play.
- Batter 0.5-hit under requires a sub-.220 average AND high K% (roughly 30%+), plus a miss-bat starter.

### General Prop Discipline

- Never add “just one more” prop after core sides are set if it lowers slip edge.
- Cap same-game batter props at two vs one starter.
- Treat ceremonial or final-career starts as short outings.
- Reliever and stolen-base props are high variance. Default them off multi-leg cards.

## 8. Factors That Do Not Reliably Win

- Simply being the favorite.
- One hot hitter or a short win streak without pitching/bullpen support.
- Ignoring the full opposing lineup.
- Assuming a large season-long ERA gap guarantees tonight.
- Clinched favorite with a paper SP edge.
- K overs on pitch-capped or playoff-prep arms.
- Moderate K lines (2.5–5.5) on non-elite pitchers.
- Slight favorites in projected low-scoring pitchers’ duels (0-1 / 1-0 upset shape).
- Copying a batter’s Coors slash line onto a road under.

## 9. Winning Shape vs Losing Shape

**Keep using**

- Full-workload starter (5+ IP expected).
- Clear ERA/FIP/WHIP/K gap vs a weak or eliminated lineup.
- Offense still has something to play for.
- Bullpen not burned in the prior 48–72 hours and no recent collapse by that favorite.
- Neutral-to-hitter park when attaching 0.5 props.

**Keep off slips**

- Clinched favorite with a paper SP edge.
- Short-leash ace K over.
- Moderate 4.5–5.5 K over on a non-elite arm.
- Slight favorite in a 6.5-total pitchers' duel.
- Full-game ML that only works if a tired closer holds.

Score each leg for similarity to recent winners vs recent losers and prefer the former.

## 10. Correlation Math (Mandatory)

Separate MLB games are close to independent. Legs inside one game are not. Follow `references/correlation-math.md`.

Protocol on every built slip:

1. Assign conservative p_i. Cap most props at 0.68. Do not post 0.75 on a paper ace favorite. Drop legs below 0.56.
2. Compute `J0 = product of p_i` and report it.
3. Tag same-game pairs as IND, REINFORCE, COMPETE, NESTED, or CONFLICT.
4. CONFLICT → split. K over + opposing contact overs is CONFLICT. NESTED (F5+full ML, hits+H+R+RBI) → one exposure.
5. COMPETE cluster of size k: `J_adj ≈ J0 × 0.80^(k-1)`.
6. Do not boost J because "the park is live." That is one run-environment bet.
7. Kill-shot test: 3 IP hook, clinch rest lineup, pen collapse, wind flip, miss-bat night. If one event kills 3+ legs, cut.
8. Caps: max 2 batter props vs one starter; max 1 K market per pitcher; no stacked 0.5 H+R+RBI card; no game over 40% of the ticket. Prefer different games for the core.

A strong 5-leg MLB core should usually be four or five different games, not five props on two pitchers.

## Practical Checklist

1. Confirm both SPs, workload expectation, and projected lineups.
2. Measure ERA/FIP/WHIP/K gap and opponent last 7–10 OPS vs that handedness.
3. Check pen ERAs and high-leverage workload last 48–72 hours. Note recent collapses.
4. Factor park, weather, umpire, injuries, and clinch/rest status.
5. Choose ML vs F5 vs total vs run line based on where the edge actually lives.
6. Ask whether the side resembles recent winners more than recent losers.
7. Apply prop filters, especially the short-outing check.
8. If the slip already has 4+ strong sides, do not force extra props.
9. Flag any leg that mirrors a known failure mode.
10. Run the victory gates in `references/victory-gates.md` before lock.

## Output Guidance

- State the size of the SP edge (ERA/FIP/WHIP/K + recent form) and expected innings.
- Flag pen fatigue, surging opposing OPS, clinched/rest status, short-leash risk, park, weather, and umpire.
- Score edge strength (clear mismatch vs marginal) and similarity to recent winning or losing patterns.
- Name the market that matches the edge (full ML, F5, total, prop).
- For props, confirm filters before inclusion.
- Warn against overloading with low-edge props.
- If evidence is weak, pass. Do not invent a lean to fill a card.
- Follow `references/output-and-intake.md` heading order on every built slip.
- Required block includes Recommended Slip table, Probability Block table, Monte Carlo script output, Kill Shots, and Final Prediction with "Reply `/run audit` to re-check this slip".
- Run `python3 scripts/monte_carlo_parlay.py` on a JSON spec. Default 20000 trials. Prefer different clusters for a multi-game core.
