# Live Data, API, and Source-Quality Contract (v4.0)

## Purpose
An API key does not make a prediction mathematically more accurate by itself. It gives the model access to fresher, deeper, more structured data. Accuracy improves only when that data is actually incorporated into the projection and calibrated against results.

## Source hierarchy
1. Official league/team information for confirmed starters, inactives, lineups, roster moves, and game status.
2. A structured sports-data API for player/team statistics, game logs, injuries, depth charts, weather, odds, and historical data.
3. A second independent public projection or market source for direction/mean validation.
4. News/social reports only as a supplement, never as the sole quantitative source for a CORE leg.

## API policy
- Never hard-code an API key in the skill, repository, prompt, or output.
- Prefer an environment/secret such as `SPORTSDATAIO_API_KEY`.
- If the key is unavailable, continue with public/official sources where possible, but mark fields that require the API as UNCONFIRMED.
- Never fabricate an API response, projection, injury, lineup, odds value, or timestamp.
- Record source name, retrieval time, and whether the field is confirmed, projected, or stale.
- Do not treat a provider's proprietary projection as ground truth. It is Source B, not the answer.

## Recommended structured provider
SportsDataIO currently documents deep league APIs for NFL, MLB, and CFB, including player/team stats and event data; its NFL workflow also covers injuries, depth charts, game-day information, odds, and player projections. API access uses an API key. Use only endpoints and fields actually available to the subscribed plan.

## Required freshness
- Starting lineup / inactives / starting QB or pitcher: re-check close to lock and again if credible news changes.
- Weather: refresh close to game time.
- Odds/props: capture the exact line and timestamp; never substitute a stale line.
- Season/game-log statistics: cache is acceptable if the game state and roster context have not changed.

## Missing-data rule
A missing required field does not become an assumed average. It becomes one of:
- `CONFIRMED`: verified current data
- `PROJECTED`: reasonable pregame estimate with source/time
- `STALE`: data exists but is too old for the decision
- `UNCONFIRMED`: required field unavailable

A CORE leg requires all critical fields to be CONFIRMED or explicitly acceptable PROJECTED inputs. Any material STALE/UNCONFIRMED field downgrades the leg to EXTRA or PASS.

## Point-in-time integrity
Never leak postgame information into a pregame projection. Historical backtests must use only data that would have been available at the prediction timestamp.
