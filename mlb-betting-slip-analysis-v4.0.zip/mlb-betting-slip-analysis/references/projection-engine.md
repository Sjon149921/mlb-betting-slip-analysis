# MLB Projection Engine

Gates do not replace a projection. A CORE row is illegal until a mean, SD or lambda, p_i, and two-source check exist.

Run `python3 scripts/project_leg.py` and, for K props, `python3 scripts/expected_k.py`.

## Order of operations

1. Fetch SP, expected IP / pitch cap, confirmed lineup slots, park, wind, umpire, motivation class.
2. Shrink 3-start samples toward career / arsenal prior.
3. Build the counting mean from batters faced or slot wOBA, not from slogans.
4. Convert to p_i with Poisson (K, hits) or normal (H+R+RBI sum, runs).
5. Two-source agreement.
6. Then tags, floors, Monte Carlo.

## Required fetches

| Market | Must fetch |
| --- | --- |
| K | expected IP or cap, K% vs this lineup (or K/9 plus opponent K%), umpire, park K factor |
| H / R / RBI / H+R+RBI | slot, handedness vs SP, SP WHIP / H9, team run expectancy, park, wind |
| F5 or full ML | both SP FIP, expected IP, pen leverage last 72h, motivation class, market p |
| Totals | both SP + pens + park + wind + umpire |

Unconfirmed lineup or unconfirmed cap → UNCONFIRMED, not CORE.

## Shrinkage

3-start samples: `0.30 * last3 + 0.70 * career_or_arsenal`.  
Velo down 1.5 mph over 3 starts: cut K% 1.5 points and raise H9 before projecting.

## Formulas

Strikeouts:

`BF = min(IP * 4.3, pitches / 4.0)`  
`expected_K_raw = BF * K_rate_vs_this_profile`  
or `K9 * IP / 9` if no matchup K-rate  
`mean = raw * 0.90`  
`p from Poisson(mean)`  
`--pitches 70` beats `--finale`. 70 pitches is ~4.4 IP, not a 5.5 K over.

Over legal only if IP ≥ 5.0, not capped, and mean ≥ line + 1.0.

H+R+RBI:

Run `scripts/matchup_bat.py --slot --woba --batter_k --sp_fip --sp_k9` first.  
`mean = E[H] + E[R] + E[RBI]` from that output, not from "soft starter = over."  
Mid-order (slot ≥ 5) + batter K ≥ 24% is EXTRA unless the gap is 1.0+. Happ 0-for-5 vs Houck.  
Variance is not the sum of three independents. Use `sd = sqrt(mean + 0.35*mean)`.  
Elite-bat under is illegal when team run expectancy ≥ 5.0 unless a true ace is on the mound.

Holdout update (v3.1):

- Leadoff / star H+R+RBI **over vs an ace** (FIP or ERA ≤ 3.00): CORE only if p_i ≥ 0.60 and mean ≥ line + 0.8. Otherwise EXTRA. PCA over 1.5 vs Henderson 2.47 was a 0.56 kiss.
- p_i 0.52–0.56 counting overs are EXTRA, not CORE and not auto-deleted.
- K over floor stays +1.0 expected K. Gausman 5.58 vs 5.5 and Henderson 4.68 vs 5.5 both cashed 6 K and stay off CORE. That is the point of the floor.

Holdout update (v3.2):

- Any H+R+RBI **over** needs p_i ≥ 0.60 and mean ≥ line + 0.60 for CORE. Happ over 1.5 at 0.565 went 0-for-5 on 2026-09-27.
- Last week / clinch / finale: pass `--finale` on K props. Treat as capped unless 5+ IP is confirmed. Imanaga 3 K in 1 IP.

Team runs / winner:

Build each team's run mean from SP FIP, lineup wOBA vs handedness, park factor, wind.  
`python3 scripts/project_leg.py winner --runs 4.6 --opp 3.2 --motivation fighting --opp_motivation eliminated`  
Eliminated-team winner is illegal. Locked vs fighting gets a 0.88 haircut. |run gap| < 0.8 caps p at 0.58.

## Two-source agreement

Model mean vs market implied total, F5, or a second projection. Same side of the line. Winner implied-p split > 10 points is not CORE.

## Cross-sport governor

Winner cap is per ticket, not per league. Two NFL winners plus two MLB winners on one Underdog card is four winners. Illegal. 10 picks at 3.33x is a rebuild.

## After the game

```
python3 scripts/log_result.py --id L3 --market k --player "J. Jones" --line 5.5 --side over --mean 4.0 --p 0.41 --actual 5 --hit 0
```
