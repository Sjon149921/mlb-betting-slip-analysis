# Projection Framework v4.0

Every candidate must pass this order. Do not jump directly from a player's average to a pick.

1. **Opportunity** — expected innings, batters faced, plate appearances, snaps, routes, targets, carries, dropbacks, possessions, or other role volume.
2. **Matchup-adjusted efficiency** — opponent quality, handedness/front, coverage/pressure, park/weather, and relevant scheme effects.
3. **Game-script distribution** — model at least lead/neutral/trail or equivalent scenarios and weight them by the pregame script distribution.
4. **Outcome distribution** — calculate mean, median, and SD/variance. A mean alone is insufficient.
5. **Probability** — derive P(over/under/win) from the distribution; do not choose p_i by intuition.
6. **Second-source validation** — compare against an independent projection or market-derived mean. Disagreement is a reason to downgrade, not average blindly.
7. **Robustness / sensitivity** — perturb workload, efficiency, and script assumptions within reasonable ranges. If a small change flips the side, the leg is EXTRA/PASS.
8. **Correlation** — tag same-game legs only after individual probabilities are established.
9. **Kill-shot audit** — identify events that can invalidate multiple legs.
10. **Calibration** — compare predicted probabilities with empirical outcomes by market bucket.

## Probability vs edge
Keep these separate:
- `p_model`: model probability of the outcome.
- `p_market`: market-implied probability when a usable market price exists.
- `edge = p_model - p_market`.
- `robustness`: how much p_model changes under reasonable input perturbations.

A high p_model with poor robustness is not automatically a good CORE leg. A low-information market should not be treated as an authoritative Source B.

## No arbitrary probability ceilings
Do not pretend a universal 0.68/0.70 cap is a calibrated truth. Use conservative caps only as a risk-control display rule. The underlying probability must remain available for calibration.

## Calibration requirement
Maintain reliability buckets (for example 0.50–0.55, 0.55–0.60, 0.60–0.65, etc.) and market buckets. Change thresholds only after sufficient sample size. One loss or one win never changes a rule.

## Failure classification
After each result classify the miss as one of:
- model error
- data error
- workload/opportunity error
- script error
- correlation/construction error
- normal variance

Do not alter the model merely because an outcome was surprising.
