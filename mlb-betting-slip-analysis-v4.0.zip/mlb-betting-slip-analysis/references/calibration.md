# Calibration Log

`logs/calibration.jsonl` stores every published CORE/EXTRA row and its result.

Append with `scripts/log_result.py` after the slate. Read the last 30 rows before changing K or H+R+RBI floors.

Change a floor only when a bucket (finale K overs, elite-bat unders, eliminated MLs) has n ≥ 8 and the hit rate is 8+ points off posted p_i.

v3.1 after holdout: H+R+RBI over vs ace (ERA/FIP ≤ 3.00) needs p_i ≥ 0.60 and mean ≥ line + 0.8 (PCA vs Henderson). Sides at 0.52–0.56 are EXTRA.

Known misses already in the log:

- Alvarez under 2.5 H+R+RBI in HOU 9–0 (2026-09-27)
- Jared Jones over 5.5 K on a 4-IP finale
- Parker Messick over 3.5 K in 3 IP post-clinch
- Diamondbacks winner, season finale, already eliminated


## v4.0 calibration additions

Store both raw model probability and any conservative ticket probability. Do not calibrate the clipped value as if it were the model's actual belief.

Track reliability by market bucket and probability bucket. Minimum rule-change sample: n >= 30 for exploratory observations; prefer n >= 50 before materially changing a CORE threshold. A single surprising result never changes a gate.

For every miss, label the failure mode: model, data, opportunity/workload, script, correlation/construction, or normal variance.

For backtests, use only information available at the prediction timestamp. No postgame line movement, confirmed late inactive, or final box-score data may leak into a historical pregame projection.
