# MLB Markets and Filters

## F5 vs Full Game

F5 settles on the score after five innings and isolates most of the starter's work.

Use F5 when:

- The SP edge is large
- The favorite's pen is tired or has recently collapsed
- The opponent's pen is the only reason the full-game number is tight

Avoid F5 as a "safer ML" when:

- The starter is an opener or is not expected to finish five
- The lineup is unconfirmed and the top of the order may be rested
- Settlement rules require five full innings and weather/delay risk is high

F5 totals often sit near 45–55% of the full-game total. Price F5 totals from the two SPs, the top of both orders, park, and umpire — not by blindly halving the full total.

## Run Line

-1.5 favorites cover less often in bullpen games and in low-total pitchers' duels. Require a true mismatch plus a healthy pen before putting a run-line favorite on a multi-leg slip.

+1.5 dogs are not automatic just because baseball is noisy. Need a respectable SP or a pen/motivation reason the favorite fails to finish.

## Totals Construction

Project runs from:

1. Both SPs' recent FIP/WHIP and opponent OPS vs handedness
2. Both pens' recent form and workload
3. Park run factor
4. Wind and temperature
5. Umpire zone
6. Lineup quality (not just season team RPG)

Do not take a total over solely because two offenses "can rake" if both SPs miss bats and the park kills offense.

## Statcast and Underlying Signals

Prefer these over raw ERA when they conflict:

- FIP / xFIP / SIERA
- CSW% and chase rate
- Barrel% and xwOBA against
- Fastball velocity trend
- Whiff% vs that lineup's chase profile

A shiny ERA with crashing velo and rising barrels is not an ace tonight.

## Weather Thresholds

- Wind 10+ mph aligned with a park's HR direction — adjust HR/total.
- Extreme heat at hitter parks — small over lean if the SPs are average.
- Cold + wind in at pitcher parks — under lean.
- Delay risk — reduce confidence in K overs and F5 settlement.

## Umpires

Wide-zone umpires slightly help K overs and unders on totals. Tight-zone umpires do the opposite. Treat as a tiebreaker, not a primary reason.

## Motivation Calendar

From September onward, classify each team as:

- Fighting for a bye, division, or play-in
- Locked into a seed and likely to rest or cap pitchers
- Eliminated

Locked and eliminated sides need a larger raw SP gap than fighting sides.

Season-finale / clinch-rest K rule: if the team has already clinched or the start is a planned short outing (coach says 4 IP, "regardless of a no-hitter"), do not take a K over that needs a full-start K/9 × 5+ IP. Jared Jones 5 Ks in 4 scheduled innings vs 5.5 is the template. Parker Messick 2 Ks in 3 IP the day after a division clinch is the same template on the other side of the ball. Prefer the under or pass.

Star-batter under vs a punching-bag staff: default off-card. Alvarez under 2.5 H+R+RBI in a Houston 9–0 win over the Athletics needed a dead bat in a 9-run script. One single + one run + one RBI = 3. Unders on elite bats require a true ace, a pitch-cap opponent, or a rest day — not a late-September mismatch.
