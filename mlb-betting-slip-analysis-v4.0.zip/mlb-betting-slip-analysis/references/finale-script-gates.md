# Finale, Clinch, and Script Gates

Worked failure: Underdog 10-pick mixed NFL+MLB card, 2026-09-27, $10 at 3.33x. Predictions cashed out $4.54. Fantasy 1-of-5.

MLB legs on that card:

| Leg | Line | Actual | Why the projection was illegal |
| --- | --- | --- | --- |
| Diamondbacks Winner | ML | Lost 4–9 at Petco | Season finale. Phillies had already clinched the last WC. Arizona was scoreboard-watching an elimination. Padres had clinched Saturday, rested Tatis/Merrill/Bogaerts, and still won. Eliminated-road + locked-home is not a winner. |
| White Sox Winner | ML | Won 4–2 vs COL | Only MLB winner that had a mismatch (58–104 Rockies). Still should not have been winner #5 on a 10-leg ticket. |
| Alvarez under 2.5 H+R+RBI | 2.5 | 3 in HOU 9–0 | Elite bat vs a punching-bag staff in a blowout. One single + one run + one RBI = miss. The under needed a dead bat inside a 9-run script. |
| Jared Jones over 5.5 K | 5.5 | 5 K in a scheduled 4-IP finale | Expected K = K/9 × IP / 9 × 0.90. Even 12.0 K/9 × 4 IP = 4.8 raw, 4.3 after haircut. Line 5.5 is above the ceiling. |
| Parker Messick over 3.5 K | 3.5 | 2 K in 3 IP | Day after Cleveland clinched. 9.0 K/9 × 3 IP = 3.0 raw. Line 3.5 needs a full start he was not going to throw. |

## Expected-K Formula (mandatory before any K prop)

```
expected_k = (K9 * expected_IP / 9) * 0.90
```

Run `python3 scripts/expected_k.py --k9 K --ip IP --line LINE [--cap]`.

| Condition | Action |
| --- | --- |
| `--cap` or expected_IP < 4.5 | K over is banned. K under only if expected_k ≤ line − 0.8 |
| expected_k ≥ line + 1.0 and IP ≥ 5.0 | K over may be CORE |
| expected_k ≤ line − 0.8 | K under may be CORE |
| otherwise | PASS. On the number |

Do not use season K/9 against a 4-inning leash and call it 5.5. The line is priced for a normal start. The leash is the whole bet.

Templates that must fail this gate on sight:

- Jones 5.5 K, 4 scheduled IP
- Messick 3.5 K, 3 IP post-clinch
- Any "he usually gets 6" over when the skipper has already said pitch count

## Season-Finale / Clinch Motivation Gate

From September 15 onward, label every team before any ML or K over:

- FIGHTING — bye, division, or play-in still live
- LOCKED — seed frozen, rest and caps likely
- ELIMINATED — nothing left

Hard rules:

- ELIMINATED road winner is off CORE. Arizona at Petco on the day Philadelphia clinched the last WC is the template.
- LOCKED home team resting regulars is not an automatic fade if the opponent is ELIMINATED. San Diego sat stars and still scored 9.
- FIGHTING vs ELIMINATED is the only finale ML shape that can be CORE, and only with a real SP + pen gap.
- Any K over on a LOCKED or ELIMINATED team's starter requires a confirmed 5+ IP plan in writing. "Probably 5" is not confirmation.

## Elite-Bat Under Gate

An under on H, R, RBI, or H+R+RBI for a middle-of-the-order bat (3-hole / 4-hole / established 120+ wRC+) is off CORE unless at least two of these are true:

1. Opposing starter is a true ace (FIP well above league, miss-bat profile)
2. Opponent is pitch-capped or the game is a bullpen day that will not see the order a third time
3. The batter is in a rest / lefty-platoon / late-scratch spot

A 9–0 script produces cheap counting stats. Alvarez 3 vs 2.5 in a shutout is not variance. It is the script the under needed not to happen. Default the side to the over or to pass.

## Cross-Sport Ticket Governor

Winner caps are per ticket, not per sport.

This 10-pick had five winner contracts: SEA, BUF, KC, ARI, CWS. NFL skill allows max 2 winners on a mixed card. MLB skill allows max 2. Together they still allow only 2. Three NFL winners plus two MLB winners is the banned 4-winner football shape wearing a baseball hat.

If the user is mixing NFL and MLB on Underdog / PrizePicks:

- Count every "To win" / team winner / ML on the slip, regardless of league
- Cap CORE winners at 2
- Cap total published legs at 6 unless J_adj ≥ 0.02 and the multiplier is ≥ 5x on 8+
- 10 picks at 3.33x is an automatic rebuild in both skills
- Refuse the opposite winner of a live ticket in the same conversation (SEA here vs WAS on PrizePicks)

## What would have been legal on that Sunday

- Cook over 79.5 as a standalone volume RB (141). Not paired with Walker 79.5.
- White Sox ML only as an EXTRA on a 3-leg core, not winner #5
- Jones and Messick K overs: deleted by the formula
- Alvarez under: deleted by the elite-bat gate
- Arizona winner: deleted by the eliminated-road gate
