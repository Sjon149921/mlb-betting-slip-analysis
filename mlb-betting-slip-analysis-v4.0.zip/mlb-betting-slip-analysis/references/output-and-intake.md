# Intake, Output Template, Monte Carlo, Audit

## Command Map

- Skill start or "build slip" with missing fields → Intake first.
- `/run audit` or "run audit" → audit the most recent slip and re-run Monte Carlo.
- `/run audit mlb` also triggers this path.

Skip fields already answered.

## Intake (ask in this order)

Required:

1. Games / pitchers on the ticket.
2. Ticket type — team winners (full ML), F5 ML, run line, pitcher props, batter props, totals, or mix. Ask Winner vs run line vs F5 explicitly on PrizePicks Predict — Winner has no push and no F5 escape.
3. Leg count — core 3–6 recommended. 8 ceiling. 12–16 entertainment only.
4. Platform. PrizePicks combined Player + Team lineups are Power Play only. If the user wants 4 winners + 2 props, refuse that shape.
5. Risk mode — core only, core plus extras, or entertainment long card.

Useful follow-ups:

6. Confirmed starters, expected IP / pitch caps, lineups.
7. Clinched / seeding / elimination status they already know.
8. Must-include / must-avoid pitchers or hitters. If a game is already live on another platform in the opposite direction, refuse that fade.
9. Unders allowed — default yes.
10. Park and weather notes they already have.
11. Prefer F5 when the pen is the worry — ask if they will accept F5 instead of full ML.

Ask unanswered required fields. Then build.

## Fixed Output Template

Use these headings in this order.

### 1. Intake Recap
### 2. Pitching Board
Per game: SP edge, expected IP, pen heat, park/weather, motivation class.

### 3. Candidate Pool
### 3b. Projection Block
Mandatory. Run `python3 scripts/project_leg.py` (and `expected_k.py` on K props). No CORE row without mean, p_i, and a LEGAL flag.

| ID | Market | Mean | IP / slot | Line | Gap | p_i | Motivation | Flag |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |

### 4. Recommended Slip

| ID | Game | Market | Side / Line | IP / slot path | Projection | Gap | p_i | Tag vs slip | Role |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |

### 5. Probability Block

| Metric | Value |
| --- | --- |
| Legs in published core | |
| Product J0 (independence) | |
| Compete/conflict adjusted J | |
| Monte Carlo all-hit | |
| Monte Carlo at least n-1 | |
| Monte Carlo at least n-2 | |
| Mean hits in MC | |
| Posted multiplier if known | |
| Pass pricing gate | YES or NO |

Pair tag table required.

### 6. Monte Carlo
`python3 scripts/monte_carlo_parlay.py /tmp/slip.json`

### 7. Kill Shots
3 IP hook, clinch rest lineup, pen collapse, wind flip, miss-bat night vs contact stack. Fail if one event kills 3+ CORE legs.

### 8. Final Prediction
Core ticket, extras labeled, gate pass/fail.
Closing line: Reply `/run audit` to re-check this slip against lineup/weather/pitch-cap news and a fresh Monte Carlo.

### 9. Open Risks

## Audit Mode (`/run audit`)

Restate CORE, refresh SP/lineup/weather/pen, re-tag, re-run Monte Carlo, verdict HOLD / CUT-AND-REPLACE / KILL TICKET, reprint Probability Block old vs new.

## Monte Carlo Spec Notes

Same-game legs share `cluster`. K over vs opposing contact over is CONFLICT. F5 + full ML is NESTED (`a` = full ML if it needs the F5 to hold plus the pen). Prop p_i cap 0.68. Drop below 0.56. Prefer different `cluster` values for a multi-game core.


## v4.0 data status
Every candidate table must identify critical inputs as CONFIRMED, PROJECTED, STALE, or UNCONFIRMED. Record the data timestamp for lines, weather, injuries/inactives, and starting roles. A CORE recommendation may not silently rely on stale or missing critical inputs.
