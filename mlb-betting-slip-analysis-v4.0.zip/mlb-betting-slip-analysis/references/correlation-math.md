# MLB Correlation Math

Baseball looks more independent than football or basketball because games are high-variance and slates are large. Inside one game they are not independent. One starter's innings, one run environment, and one pen inning can move ML, F5, K, and batter props together.

## 1. Assign a conservative p_i

1. Build from SP edge, expected IP, opponent OPS/K% vs handedness, pen, park, and weather.
2. Haircut single-game baseball noise. Do not post 0.75 on a -160 favorite just because the ace is pitching.
3. Cap most player props at 0.68. 0.5 H+R+RBI can run higher only with a real run environment and a top-order slot.
4. If p_i < 0.56 after haircut, it is not a parlay leg.

## 2. Naive joint is only a starting number

`J0 = p1 × p2 × … × pn`

- 4 × 0.62 → ≈ 0.148
- 6 × 0.62 → ≈ 0.057
- 8 × 0.62 → ≈ 0.022
- 16 mixed 0.56–0.78 → well under 0.002 after any correlation penalty

Report J0, then adjust. A 16-leg MLB prop card is a lottery ticket even when every individual lean is honest.

## 3. Tag every pair

| Tag | Meaning | Joint vs J0 |
| --- | --- | --- |
| IND | Different games | J0 usable |
| REINFORCE | Same world helps both (soft SP + two top-order 0.5 hits) | J0 close; wipeout risk rises |
| COMPETE | Finite hits, RBIs, or innings | Joint < J0 |
| NESTED | Component inside a combo or F5 inside full game | Joint ≈ min(pA, pB) |
| CONFLICT | Need opposite run worlds or K vs contact | Joint near 0 |

## 4. Adjust the joint

- CONFLICT → reject or split.
- NESTED → one exposure. Full-game ML + F5 ML on the same side is not two edges. Hits + H+R+RBI on the same batter is not two edges.
- COMPETE cluster of size k ≥ 2 → `J ≈ J0 × 0.80^(k-1)`
- REINFORCE k ≥ 3 vs one starter → do not inflate J. One quality start or one short outing deletes the cluster.
- Collapse each game before multiplying across the slate. Separate games are the closest thing baseball has to true independence.

Worked example:

Ace K over 6.5 (0.60), ace team ML (0.63), opponent 2-hole 0.5 H+R+RBI (0.58), opponent 3-hole 0.5 H+R+RBI (0.57).

J0 ≈ 0.125

Tags: K over + two opposing batter overs = CONFLICT (miss-bat night vs contact night). Two batter 0.5s = COMPETE/REINFORCE mix (soft SP helps both; finite baserunners). ML + K over = mild REINFORCE only if the ace works deep.

Reject the batter stack or reject the K over. Do not keep all four.

Legal rebuild: ace team F5 ML + ace K over (both need length and miss bats). Or two top-order 0.5s vs a high-WHIP non-ace, with no K over on that same pitcher.

## 5. Kill-shot test (mandatory)

MLB kill shots:

- Starter pulled after 3 IP (pitch cap, injury, weather delay, hook)
- Clinched-team rest lineup vs paper SP edge
- Pen collapse after the 6th
- Wind flips the run environment
- Ace's miss-bat night (kills opposing 0.5 stacks)
- Walk-off / extra-inning / one-run finish (deletes a full-game winner that would have been fine as F5 or run line)

If one event kills 3+ legs, cut the cluster.

## 6. Construction caps

- Max 2 batter props vs the same starter.
- Max 1 K market per pitcher.
- Do not stack 0.5 H+R+RBI props across the slip.
- Do not pair a pitcher's K over with opposing contact overs.
- Full-game ML + F5 ML on the same team = 1 exposure.
- Mixed Power Play: max 2 full-game ML / winner legs in CORE. Winners-only CORE: max 3.
- Four pick'em / one-run ML winners on one all-must-hit card is an automatic rebuild.
- No game may carry more than 40% of a multi-game card.
- Core 3–6 sides. 8 only if most legs are different games and J_adj ≥ 0.02.

## 7. Pair dictionary

REINFORCE

- Full-workload miss-bat SP + that team's ML or F5 ML
- Soft-WHIP SP + top-order batter over in a high-run park
- Two unders in a true duel (low total + modest K under only if IP math says so)
- Burned opposing pen + full-game ML for the side that can reach the late innings

COMPETE

- Two 0.5 H+R+RBI overs vs the same starter
- Three hit overs against one arm
- Two K overs that both need 6+ IP from mid-rotation starters on short rest

NESTED

- Hits + H+R+RBI on the same batter
- F5 ML + full-game ML on the same team
- Team total over + multiple batter overs from that lineup

CONFLICT

- Pitcher K over + opposing lineup contact overs
- Large SP-edge ML + opposing 0.5 stacks
- Elite-duel under + Coors-style batter overs in the same game
- Full-game ML that needs a tired closer + F5 fade on the same side

## 8. Slate independence is the MLB advantage

Use it. A strong 5-leg MLB core should usually be five different games, or four games with at most one two-leg script pair. That is how baseball parlays avoid a single short outing wiping the card.

## 9. Output block (required)

- p_i per leg
- Pair tags inside each game
- J0 and J_adj
- Kill shots
- Core vs speculative
- Nested F5/full or hit/combo markets collapsed
