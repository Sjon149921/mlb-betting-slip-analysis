# MLB Victory Gates

Run every candidate slip through these gates before presenting it.

## Pricing and Payout

- Compute implied joint hit rate from individual probabilities. A 16-leg card of 0.56–0.78 legs still jointly cashes well under 0.2% after correlation. Report that math.
- Prefer an 8-leg or smaller core when the user will tolerate it. Always publish the core even if they insist on 16.
- If the posted multiplier is below 1.2x on four or more legs, rebuild or pass.
- If the card has 8 or more legs and the posted multiplier is under 5x (example: 10 picks at 3.33x), rebuild.
- A "Won" badge at 0.5x–0.9x is a losing ticket. Cashout is not a projection method.
- Never add a last leg to manufacture a jackpot.

## Correlation Math Gate

- Read `correlation-math.md` before lock.
- Print p_i, J0, J_adj, pair tags, and kill-shots.
- Collapse F5 + full ML, and hits + H+R+RBI, to one exposure each.
- Prefer different games for the core. That is baseball's real diversification.

## Correlation

- Cap same-game batter props at two vs one starter.
- Do not stack 0.5 H+R+RBI props on the same slip.
- Do not mix "soft SP, high-run game" batter overs with "elite SP duel" unders on the same game.
- Team ML + opposing lineup 0.5 props require the opponent to score. That fights a large SP-edge ML. Split tickets if scripts conflict.
- Multiple K overs on the same slip require independent full-workload assumptions. One short outing should not kill three legs if you can avoid it — do not stack two K overs that both need 6+ IP from mid-rotation arms. Season-finale and post-clinch starts are short-outing priors (Jones 4 scheduled IP, Messick 3 IP the day after Cleveland clinched).
- Do not take an elite-bat H+R+RBI under against a punching-bag staff. Alvarez under 2.5 in a 9–0 Houston win is a script conflict.

## Cushion Floors

Do not take a prop whose projection sits on the number.

| Market | Minimum gap | Extra filter |
| --- | --- | --- |
| Pitcher K over | Projection ≥ 1.0 K above the line | Last 3–5 K/start above the line; opponent K% ≥ league average; 5+ IP expected. Season finale / clinch-rest / coach-announced cap voids the over. |
| Pitcher K under | Projection ≥ 0.8 K below the line | Confirmed cap or clearly low K/9 × IP |
| Batter 0.5 hit / 0.5 H+R+RBI | Team projected ≥ 4.5 runs or SP WHIP clearly soft | Order slot 1–5 preferred; not a pitch-capped opponent |
| Hits / total bases over | Meaningful volume path, not one HR | Park and wind aligned |

## Sample and Timing

- Do not treat one start as a new identity.
- Confirm lineup and weather inside 60–90 minutes of first pitch when possible.
- Late scratches void or reprice. Say so rather than holding a dead lean.
- Playoff-prep and clinch rest become first-class variables from mid-September onward.

## Platform, Void, and Alternate-Line Notes

- Flex products do not fix a 16-leg MLB prop lottery.
- A rain delay or late SP scratch voids or reprices. Do not need the void to make the card work.
- If two batter overs COMPETE, keep the better slot/platoon and drop the other rather than lowering both to 0.5 and stacking.
- F5 and full-game ML on the same side are one bet. Do not collect both as "diversification."

## Team Winner / Full-Game ML Cluster Gate

Worked football failure that applies here: PrizePicks 6-Pick Power Play, NFL 2026 Week 3. Two player props and one huge-dog winner cashed; three close winner contracts died on a walk-off FG, a fourth-quarter turnover collapse, and a 0–2 home side against a 3–0 opponent. Shape was 2 props + 4 winners. Banned in football; same shape is banned in baseball.

Worked mixed-card failure: Underdog 10-pick, 2026-09-27, $10 at 3.33x. Predictions cashed out at $4.54 (Seattle favorite lost 31–33; Arizona lost 4–9). Fantasy 1-of-5. Alvarez under 2.5 H+R+RBI missed at 3 in Houston's 9–0 win. Jones over 5.5 Ks missed at 5 in a scheduled 4-IP finale. Messick over 3.5 Ks missed at 2 in 3 IP the day after Cleveland clinched. If 8+ legs pay under 5x, rebuild.

Hard rules:

- Winner caps are per ticket, not per sport. NFL winners and MLB winners on the same Underdog card share one cap of 2.
- Mixed player + team Power Play: max 2 full-game ML / winner legs in CORE.
- Winners-only CORE: max 3, and at least two need a real SP + pen + lineup gap, not "pick'em / one-run game" pricing.
- Never 4+ close ML legs on an all-must-hit 6-leg card.
- Cap p_i on pick'em / one-run priced winners at 0.58. Extra-inning and bullpen-collapse variance is the baseball version of a walk-off FG.
- If conviction is the starter and doubt is the pen, take F5 ML instead of the full-game winner.
- If the lean is "they keep it close," take the run line when offered. Winner has no push.
- Combined PrizePicks Player + Team lineups are Power Play only.

## Projection-First Gate

No CORE row without a LEGAL flag from `scripts/project_leg.py`. K overs also need `scripts/expected_k.py`. Invented p_i is a failed audit.

## Cross-Sport Ticket Governor

Winner cap is per ticket. NFL winners and MLB winners share one cap of 2. Eight or more legs paying under 5x is a rebuild.

## Pass Rule

If the only reason to include a leg is payout, popularity, or "it looks close enough," remove it.
