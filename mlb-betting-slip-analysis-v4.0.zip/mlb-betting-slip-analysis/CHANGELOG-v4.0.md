# MLB Betting Skill v4.0 Upgrade

- Added explicit opportunity → efficiency → script → distribution → probability workflow.
- Added mean/median/SD and robustness requirements.
- Separated p_model from ticket-level conservative p_i and market edge.
- Added live-data quality states and API/secret handling.
- Added point-in-time integrity requirements for backtests.
- Added structured failure classification and stronger calibration rules.
- Removed arbitrary model-level probability ceilings from projection scripts; ticket construction can still apply conservative risk controls.
- Preserved existing correlation, kill-shot, workload, and sport-specific safeguards.
